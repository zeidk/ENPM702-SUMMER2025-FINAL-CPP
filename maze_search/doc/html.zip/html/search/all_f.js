var searchData=
[
  ['turn_5fleft_0',['turn_left',['../classmicro__mouse_1_1MazeControlAPI.html#a9a353e3100f1db31802564e03901a56e',1,'micro_mouse::MazeControlAPI']]],
  ['turn_5fright_1',['turn_right',['../classmicro__mouse_1_1MazeControlAPI.html#a1810c05fe5833e0615804b855334496f',1,'micro_mouse::MazeControlAPI']]]
];

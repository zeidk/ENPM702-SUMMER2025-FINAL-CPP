var searchData=
[
  ['visualization_20and_20manipulation_0',['Visualization and Manipulation',['../index.html#autotoc_md12',1,'']]]
];

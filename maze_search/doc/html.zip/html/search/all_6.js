var searchData=
[
  ['get_5fmaze_5fheight_0',['get_maze_height',['../classmicro__mouse_1_1MazeControlAPI.html#a972f371d320a4600692e04e90412af3b',1,'micro_mouse::MazeControlAPI']]],
  ['get_5fmaze_5fwidth_1',['get_maze_width',['../classmicro__mouse_1_1MazeControlAPI.html#a725aaaffb3c3b3f9487ae5da57b87bc5',1,'micro_mouse::MazeControlAPI']]],
  ['getting_20started_2',['Getting Started',['../index.html#autotoc_md3',1,'']]]
];

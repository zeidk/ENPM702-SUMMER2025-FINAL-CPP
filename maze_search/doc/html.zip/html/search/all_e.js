var searchData=
[
  ['set_5fcolor_0',['set_color',['../classmicro__mouse_1_1MazeControlAPI.html#a2b58e9b4c44c054dfe7a7676ad8319dc',1,'micro_mouse::MazeControlAPI']]],
  ['set_5ftext_1',['set_text',['../classmicro__mouse_1_1MazeControlAPI.html#ab666935376f39d1ce6cd0a5edf981a9d',1,'micro_mouse::MazeControlAPI']]],
  ['set_5fwall_2',['set_wall',['../classmicro__mouse_1_1MazeControlAPI.html#a0716f858121a643e148fca4ad302392e',1,'micro_mouse::MazeControlAPI']]],
  ['simulator_3',['Maze Simulator',['../index.html#autotoc_md4',1,'']]],
  ['started_4',['Getting Started',['../index.html#autotoc_md3',1,'']]]
];

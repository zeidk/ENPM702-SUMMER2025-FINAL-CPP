var index =
[
    [ "Overview", "index.html#autotoc_md1", null ],
    [ "Features", "index.html#autotoc_md2", null ],
    [ "Getting Started", "index.html#autotoc_md3", [
      [ "Maze Simulator", "index.html#autotoc_md4", null ],
      [ "Configuration", "index.html#autotoc_md5", [
        [ "Build Executable", "index.html#autotoc_md6", null ],
        [ "Run Executable", "index.html#autotoc_md7", null ]
      ] ]
    ] ],
    [ "API Documentation", "index.html#autotoc_md8", [
      [ "Navigation Methods", "index.html#autotoc_md9", null ],
      [ "Wall Detection", "index.html#autotoc_md10", null ],
      [ "Maze Properties", "index.html#autotoc_md11", null ],
      [ "Visualization and Manipulation", "index.html#autotoc_md12", null ],
      [ "Reset Handling", "index.html#autotoc_md13", null ]
    ] ],
    [ "Communication Protocol", "index.html#autotoc_md14", null ],
    [ "Algorithm", "index.html#autotoc_md15", null ]
];